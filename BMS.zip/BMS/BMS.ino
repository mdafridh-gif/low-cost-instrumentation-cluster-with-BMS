#include <WiFi.h>
#include <Firebase_ESP_Client.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#include <Adafruit_AHTX0.h>

// ================= WIFI =================
#define WIFI_SSID "Sumathi"
#define WIFI_PASSWORD "Akashsumathi"

// ================= FIREBASE =================
#define API_KEY "AIzaSyBvNp_j7zhKd2T4Y7B_mcoZmi_gMpCpjng"
#define DATABASE_URL "https://bms-dashboad-9cd6b-default-rtdb.asia-southeast1.firebasedatabase.app/"

FirebaseData fbdo;
FirebaseAuth auth;
FirebaseConfig config;

// ================= TFT PINS =================
#define TFT_CS   5
#define TFT_DC   2
#define TFT_RST  4

Adafruit_ILI9341 tft = Adafruit_ILI9341(TFT_CS, TFT_DC, TFT_RST);

// ================= SENSORS =================
#define VOLTAGE_PIN 35
#define CURRENT_PIN 34

Adafruit_AHTX0 aht;

// Voltage Divider 33K / 10K
float R1 = 33000.0;
float R2 = 10000.0;

// ACS712 (30A)
float sensitivity = 0.066;
float offsetVoltage = 2.5;

// Battery
float batteryCapacityAh = 7.0;
float systemVoltage = 12.0;

void setup() {

  Serial.begin(115200);
  Wire.begin(21, 22);

  // TFT Init
  tft.begin();
  tft.setRotation(1);
  tft.fillScreen(ILI9341_BLACK);
  tft.setTextSize(2);

  // WiFi
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  tft.setCursor(20, 20);
  tft.setTextColor(ILI9341_WHITE);
  tft.print("Connecting WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected ✅");

  // Firebase
  config.api_key = API_KEY;
  config.database_url = DATABASE_URL;

  Firebase.signUp(&config, &auth, "", "");
  Firebase.begin(&config, &auth);
  Firebase.reconnectWiFi(true);

  // AHT10
  if (!aht.begin()) {
    Serial.println("AHT10 not detected!");
    while (1);
  }

  tft.fillScreen(ILI9341_BLACK);
}

void loop() {

  if (!Firebase.ready()) {
    Serial.println("Firebase Not Ready");
    delay(2000);
    return;
  }

  // -------- Voltage --------
  int adcValue = analogRead(VOLTAGE_PIN);
  float adcVoltage = adcValue * (3.3 / 4095.0);
  float batteryVoltage = adcVoltage * ((R1 + R2) / R2);

  // -------- Current --------
  float current = 0;
  for(int i=0;i<20;i++){
    float currentVoltage = analogRead(CURRENT_PIN) * (3.3 / 4095.0);
    current += (currentVoltage - offsetVoltage) / sensitivity;
    delay(2);
  }
  current /= 20.0;
  if (current < 0.05) current = 0;

  // -------- Power --------
  float power = batteryVoltage * current;

  // -------- Temperature --------
  sensors_event_t humidity, temp;
  aht.getEvent(&humidity, &temp);
  float batteryTemp = temp.temperature;

  // -------- Battery % --------
  float batteryPercent = ((batteryVoltage - 10.5) / (12.6 - 10.5)) * 100.0;
  batteryPercent = constrain(batteryPercent, 0, 100);

  // -------- Range --------
  float totalEnergyWh = batteryCapacityAh * systemVoltage;   // 84Wh
  float remainingEnergyWh = (batteryPercent / 100.0) * totalEnergyWh;
  float avgConsumptionPerKm = 100.0;
  float rangeKm = remainingEnergyWh / avgConsumptionPerKm;

  // ================= TFT DISPLAY =================
  tft.fillScreen(ILI9341_BLACK);

  tft.setTextColor(ILI9341_CYAN);
  tft.setCursor(40, 5);
  tft.print("12V Smart BMS");

  tft.setTextColor(ILI9341_GREEN);

  tft.setCursor(10, 40);
  tft.print("Voltage: ");
  tft.print(batteryVoltage, 2);
  tft.print(" V");

  tft.setCursor(10, 70);
  tft.print("Current: ");
  tft.print(current, 2);
  tft.print(" A");

  tft.setCursor(10, 100);
  tft.print("Power: ");
  tft.print(power, 2);
  tft.print(" W");

  tft.setCursor(10, 130);
  tft.print("Temp: ");
  tft.print(batteryTemp, 2);
  tft.print(" C");

  tft.setCursor(10, 160);
  tft.print("Battery: ");
  tft.print(batteryPercent);
  tft.print(" %");

  tft.setCursor(10, 190);
  tft.print("Range: ");
  tft.print(rangeKm, 2);
  tft.print(" Km");

  if (batteryVoltage < 10.5) {
    tft.setTextColor(ILI9341_RED);
    tft.setCursor(150, 220);
    tft.print("LOW BATTERY!");
  }

  // ================= FIREBASE =================
  Firebase.RTDB.setFloat(&fbdo, "/BMS_12V/Voltage", batteryVoltage);
  Firebase.RTDB.setFloat(&fbdo, "/BMS_12V/Current", current);
  Firebase.RTDB.setFloat(&fbdo, "/BMS_12V/Power", power);
  Firebase.RTDB.setFloat(&fbdo, "/BMS_12V/Temperature", batteryTemp);
  Firebase.RTDB.setFloat(&fbdo, "/BMS_12V/BatteryPercent", batteryPercent);
  Firebase.RTDB.setFloat(&fbdo, "/BMS_12V/RangeKm", rangeKm);
  Firebase.RTDB.setString(&fbdo, "/BMS_12V/Status", "CONNECTED");

  delay(2000);
}